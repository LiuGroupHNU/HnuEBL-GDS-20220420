/********************************************************************************
** Form generated from reading UI file 'ReplacePropertiesShape.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REPLACEPROPERTIESSHAPE_H
#define UI_REPLACEPROPERTIESSHAPE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>
#include "layWidgets.h"

QT_BEGIN_NAMESPACE

class Ui_ReplacePropertiesShape
{
public:
    QGridLayout *gridLayout;
    QLabel *label_57;
    QLabel *label_47;
    QSpacerItem *spacerItem;
    lay::LayerSelectionComboBox *shape_layer;

    void setupUi(QWidget *ReplacePropertiesShape)
    {
        if (ReplacePropertiesShape->objectName().isEmpty())
            ReplacePropertiesShape->setObjectName(QString::fromUtf8("ReplacePropertiesShape"));
        ReplacePropertiesShape->resize(343, 187);
        gridLayout = new QGridLayout(ReplacePropertiesShape);
#ifndef Q_OS_MAC
        gridLayout->setSpacing(6);
#endif
#ifndef Q_OS_MAC
        gridLayout->setContentsMargins(9, 9, 9, 9);
#endif
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_57 = new QLabel(ReplacePropertiesShape);
        label_57->setObjectName(QString::fromUtf8("label_57"));
        label_57->setPixmap(QPixmap(QString::fromUtf8(":/right.png")));

        gridLayout->addWidget(label_57, 0, 1, 1, 1);

        label_47 = new QLabel(ReplacePropertiesShape);
        label_47->setObjectName(QString::fromUtf8("label_47"));

        gridLayout->addWidget(label_47, 0, 0, 1, 1);

        spacerItem = new QSpacerItem(10, 281, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(spacerItem, 1, 0, 1, 3);

        shape_layer = new lay::LayerSelectionComboBox(ReplacePropertiesShape);
        shape_layer->setObjectName(QString::fromUtf8("shape_layer"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(shape_layer->sizePolicy().hasHeightForWidth());
        shape_layer->setSizePolicy(sizePolicy);

        gridLayout->addWidget(shape_layer, 0, 2, 1, 1);


        retranslateUi(ReplacePropertiesShape);

        QMetaObject::connectSlotsByName(ReplacePropertiesShape);
    } // setupUi

    void retranslateUi(QWidget *ReplacePropertiesShape)
    {
        ReplacePropertiesShape->setWindowTitle(QCoreApplication::translate("ReplacePropertiesShape", "Form", nullptr));
        label_57->setText(QString());
        label_47->setText(QCoreApplication::translate("ReplacePropertiesShape", "Layer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ReplacePropertiesShape: public Ui_ReplacePropertiesShape {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REPLACEPROPERTIESSHAPE_H
