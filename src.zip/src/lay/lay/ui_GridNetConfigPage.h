/********************************************************************************
** Form generated from reading UI file 'GridNetConfigPage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GRIDNETCONFIGPAGE_H
#define UI_GRIDNETCONFIGPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_GridNetConfigPage
{
public:
    QVBoxLayout *vboxLayout;
    QGroupBox *grid_group;
    QGridLayout *gridLayout;
    QComboBox *style1_cbx;
    QLabel *label_7;
    QFrame *line_2;
    QComboBox *style0_cbx;
    QSpacerItem *spacerItem;
    QPushButton *grid_ruler_color_pb;
    QFrame *line;
    QComboBox *style2_cbx;
    QLabel *label_2;
    QLabel *Close_style;
    QLabel *label_3;
    QPushButton *grid_grid_color_pb;
    QLabel *label_5;
    QCheckBox *show_ruler;
    QPushButton *grid_axis_color_pb;
    QSpacerItem *spacerItem1;
    QLabel *label_4;
    QLabel *label_6;
    QPushButton *grid_net_color_pb;
    QLabel *label_9;
    QLabel *label;
    QLabel *label_8;
    QFrame *line_3;

    void setupUi(QFrame *GridNetConfigPage)
    {
        if (GridNetConfigPage->objectName().isEmpty())
            GridNetConfigPage->setObjectName(QString::fromUtf8("GridNetConfigPage"));
        GridNetConfigPage->resize(483, 341);
        vboxLayout = new QVBoxLayout(GridNetConfigPage);
        vboxLayout->setSpacing(6);
        vboxLayout->setContentsMargins(11, 11, 11, 11);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        vboxLayout->setContentsMargins(9, 9, 9, 9);
        grid_group = new QGroupBox(GridNetConfigPage);
        grid_group->setObjectName(QString::fromUtf8("grid_group"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(grid_group->sizePolicy().hasHeightForWidth());
        grid_group->setSizePolicy(sizePolicy);
        grid_group->setCheckable(true);
        gridLayout = new QGridLayout(grid_group);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(9, 9, 9, 9);
        style1_cbx = new QComboBox(grid_group);
        style1_cbx->addItem(QString());
        style1_cbx->addItem(QString());
        style1_cbx->addItem(QString());
        style1_cbx->addItem(QString());
        style1_cbx->addItem(QString());
        style1_cbx->addItem(QString());
        style1_cbx->addItem(QString());
        style1_cbx->addItem(QString());
        style1_cbx->addItem(QString());
        style1_cbx->setObjectName(QString::fromUtf8("style1_cbx"));

        gridLayout->addWidget(style1_cbx, 2, 2, 1, 2);

        label_7 = new QLabel(grid_group);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_7, 10, 1, 1, 1);

        line_2 = new QFrame(grid_group);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_2, 5, 0, 1, 5);

        style0_cbx = new QComboBox(grid_group);
        style0_cbx->addItem(QString());
        style0_cbx->addItem(QString());
        style0_cbx->addItem(QString());
        style0_cbx->addItem(QString());
        style0_cbx->addItem(QString());
        style0_cbx->addItem(QString());
        style0_cbx->addItem(QString());
        style0_cbx->addItem(QString());
        style0_cbx->setObjectName(QString::fromUtf8("style0_cbx"));

        gridLayout->addWidget(style0_cbx, 6, 2, 1, 2);

        spacerItem = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem, 0, 3, 1, 1);

        grid_ruler_color_pb = new QPushButton(grid_group);
        grid_ruler_color_pb->setObjectName(QString::fromUtf8("grid_ruler_color_pb"));

        gridLayout->addWidget(grid_ruler_color_pb, 10, 2, 1, 1);

        line = new QFrame(grid_group);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line, 1, 0, 1, 5);

        style2_cbx = new QComboBox(grid_group);
        style2_cbx->addItem(QString());
        style2_cbx->addItem(QString());
        style2_cbx->addItem(QString());
        style2_cbx->addItem(QString());
        style2_cbx->addItem(QString());
        style2_cbx->addItem(QString());
        style2_cbx->addItem(QString());
        style2_cbx->addItem(QString());
        style2_cbx->addItem(QString());
        style2_cbx->setObjectName(QString::fromUtf8("style2_cbx"));

        gridLayout->addWidget(style2_cbx, 3, 2, 1, 2);

        label_2 = new QLabel(grid_group);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_2, 3, 1, 1, 1);

        Close_style = new QLabel(grid_group);
        Close_style->setObjectName(QString::fromUtf8("Close_style"));
        Close_style->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(Close_style, 2, 1, 1, 1);

        label_3 = new QLabel(grid_group);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout->addWidget(label_3, 0, 0, 1, 2);

        grid_grid_color_pb = new QPushButton(grid_group);
        grid_grid_color_pb->setObjectName(QString::fromUtf8("grid_grid_color_pb"));

        gridLayout->addWidget(grid_grid_color_pb, 4, 2, 1, 1);

        label_5 = new QLabel(grid_group);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 2, 0, 1, 1);

        show_ruler = new QCheckBox(grid_group);
        show_ruler->setObjectName(QString::fromUtf8("show_ruler"));

        gridLayout->addWidget(show_ruler, 9, 2, 1, 2);

        grid_axis_color_pb = new QPushButton(grid_group);
        grid_axis_color_pb->setObjectName(QString::fromUtf8("grid_axis_color_pb"));

        gridLayout->addWidget(grid_axis_color_pb, 7, 2, 1, 1);

        spacerItem1 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem1, 2, 4, 1, 1);

        label_4 = new QLabel(grid_group);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_4, 6, 1, 1, 1);

        label_6 = new QLabel(grid_group);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_6, 7, 1, 1, 1);

        grid_net_color_pb = new QPushButton(grid_group);
        grid_net_color_pb->setObjectName(QString::fromUtf8("grid_net_color_pb"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(grid_net_color_pb->sizePolicy().hasHeightForWidth());
        grid_net_color_pb->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(grid_net_color_pb, 0, 2, 1, 1);

        label_9 = new QLabel(grid_group);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout->addWidget(label_9, 6, 0, 1, 1);

        label = new QLabel(grid_group);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label, 4, 1, 1, 1);

        label_8 = new QLabel(grid_group);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 9, 0, 1, 1);

        line_3 = new QFrame(grid_group);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_3, 8, 0, 1, 5);


        vboxLayout->addWidget(grid_group);


        retranslateUi(GridNetConfigPage);

        QMetaObject::connectSlotsByName(GridNetConfigPage);
    } // setupUi

    void retranslateUi(QFrame *GridNetConfigPage)
    {
        GridNetConfigPage->setWindowTitle(QApplication::translate("GridNetConfigPage", "Settings", nullptr));
        grid_group->setTitle(QApplication::translate("GridNetConfigPage", "Show background decoration", nullptr));
        style1_cbx->setItemText(0, QApplication::translate("GridNetConfigPage", "Invisible", nullptr));
        style1_cbx->setItemText(1, QApplication::translate("GridNetConfigPage", "Dots", nullptr));
        style1_cbx->setItemText(2, QApplication::translate("GridNetConfigPage", "Dotted lines", nullptr));
        style1_cbx->setItemText(3, QApplication::translate("GridNetConfigPage", "Light dotted lines", nullptr));
        style1_cbx->setItemText(4, QApplication::translate("GridNetConfigPage", "Dotted lines, ten dots per division ", nullptr));
        style1_cbx->setItemText(5, QApplication::translate("GridNetConfigPage", "Crosses", nullptr));
        style1_cbx->setItemText(6, QApplication::translate("GridNetConfigPage", "Lines", nullptr));
        style1_cbx->setItemText(7, QApplication::translate("GridNetConfigPage", "Lines with ticks, ten ticks per division", nullptr));
        style1_cbx->setItemText(8, QApplication::translate("GridNetConfigPage", "Checkerboard", nullptr));

        label_7->setText(QApplication::translate("GridNetConfigPage", "Color", nullptr));
        style0_cbx->setItemText(0, QApplication::translate("GridNetConfigPage", "Invisible", nullptr));
        style0_cbx->setItemText(1, QApplication::translate("GridNetConfigPage", "Dots", nullptr));
        style0_cbx->setItemText(2, QApplication::translate("GridNetConfigPage", "Dotted lines", nullptr));
        style0_cbx->setItemText(3, QApplication::translate("GridNetConfigPage", "Light dotted lines", nullptr));
        style0_cbx->setItemText(4, QApplication::translate("GridNetConfigPage", "Dotted lines, ten dots per division ", nullptr));
        style0_cbx->setItemText(5, QApplication::translate("GridNetConfigPage", "Crosses", nullptr));
        style0_cbx->setItemText(6, QApplication::translate("GridNetConfigPage", "Lines", nullptr));
        style0_cbx->setItemText(7, QApplication::translate("GridNetConfigPage", "Lines with ticks, ten ticks per division", nullptr));

        grid_ruler_color_pb->setText(QString());
        style2_cbx->setItemText(0, QApplication::translate("GridNetConfigPage", "Invisible", nullptr));
        style2_cbx->setItemText(1, QApplication::translate("GridNetConfigPage", "Dots", nullptr));
        style2_cbx->setItemText(2, QApplication::translate("GridNetConfigPage", "Dotted lines", nullptr));
        style2_cbx->setItemText(3, QApplication::translate("GridNetConfigPage", "Light dotted lines", nullptr));
        style2_cbx->setItemText(4, QApplication::translate("GridNetConfigPage", "Dotted lines, ten dots per division ", nullptr));
        style2_cbx->setItemText(5, QApplication::translate("GridNetConfigPage", "Crosses", nullptr));
        style2_cbx->setItemText(6, QApplication::translate("GridNetConfigPage", "Lines", nullptr));
        style2_cbx->setItemText(7, QApplication::translate("GridNetConfigPage", "Lines with ticks, ten ticks per division", nullptr));
        style2_cbx->setItemText(8, QApplication::translate("GridNetConfigPage", "Checkerboard", nullptr));

        label_2->setText(QApplication::translate("GridNetConfigPage", "Far style", nullptr));
        Close_style->setText(QApplication::translate("GridNetConfigPage", "Close style", nullptr));
        label_3->setText(QApplication::translate("GridNetConfigPage", "Color (all)", nullptr));
        grid_grid_color_pb->setText(QString());
        label_5->setText(QApplication::translate("GridNetConfigPage", "Grid   ", nullptr));
        show_ruler->setText(QApplication::translate("GridNetConfigPage", "Show Ruler", nullptr));
        grid_axis_color_pb->setText(QString());
        label_4->setText(QApplication::translate("GridNetConfigPage", "Style", nullptr));
        label_6->setText(QApplication::translate("GridNetConfigPage", "Color", nullptr));
        grid_net_color_pb->setText(QString());
        label_9->setText(QApplication::translate("GridNetConfigPage", "Axis", nullptr));
        label->setText(QApplication::translate("GridNetConfigPage", "Color", nullptr));
        label_8->setText(QApplication::translate("GridNetConfigPage", "Ruler", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GridNetConfigPage: public Ui_GridNetConfigPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GRIDNETCONFIGPAGE_H
