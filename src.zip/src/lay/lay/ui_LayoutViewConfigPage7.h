/********************************************************************************
** Form generated from reading UI file 'LayoutViewConfigPage7.ui'
**
** Created by: Qt User Interface Compiler version 5.12.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LAYOUTVIEWCONFIGPAGE7_H
#define UI_LAYOUTVIEWCONFIGPAGE7_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_LayoutViewConfigPage7
{
public:
    QVBoxLayout *vboxLayout;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QLabel *label_2;
    QComboBox *oversampling;
    QSpacerItem *spacerItem;
    QLabel *label;
    QGroupBox *groupBox_4;
    QHBoxLayout *hboxLayout;
    QLabel *label_4;
    QComboBox *default_font_size;
    QSpacerItem *spacerItem1;
    QGroupBox *groupBox_2;
    QHBoxLayout *hboxLayout1;
    QLabel *label_3;
    QComboBox *global_trans;
    QSpacerItem *spacerItem2;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout1;
    QLabel *label_13;
    QSpinBox *def_depth;
    QSpacerItem *spacerItem3;
    QLabel *label_14;

    void setupUi(QFrame *LayoutViewConfigPage7)
    {
        if (LayoutViewConfigPage7->objectName().isEmpty())
            LayoutViewConfigPage7->setObjectName(QString::fromUtf8("LayoutViewConfigPage7"));
        LayoutViewConfigPage7->resize(791, 385);
        vboxLayout = new QVBoxLayout(LayoutViewConfigPage7);
        vboxLayout->setSpacing(6);
        vboxLayout->setContentsMargins(11, 11, 11, 11);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        vboxLayout->setContentsMargins(9, 9, 9, 9);
        groupBox = new QGroupBox(LayoutViewConfigPage7);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(9, 9, 9, 9);
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        oversampling = new QComboBox(groupBox);
        oversampling->addItem(QString());
        oversampling->addItem(QString());
        oversampling->addItem(QString());
        oversampling->setObjectName(QString::fromUtf8("oversampling"));

        gridLayout->addWidget(oversampling, 1, 1, 1, 1);

        spacerItem = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem, 1, 2, 1, 1);

        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setWordWrap(true);

        gridLayout->addWidget(label, 0, 0, 1, 3);


        vboxLayout->addWidget(groupBox);

        groupBox_4 = new QGroupBox(LayoutViewConfigPage7);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        hboxLayout = new QHBoxLayout(groupBox_4);
        hboxLayout->setSpacing(6);
        hboxLayout->setContentsMargins(11, 11, 11, 11);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        hboxLayout->setContentsMargins(9, 9, 9, 9);
        label_4 = new QLabel(groupBox_4);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        hboxLayout->addWidget(label_4);

        default_font_size = new QComboBox(groupBox_4);
        default_font_size->addItem(QString());
        default_font_size->addItem(QString());
        default_font_size->addItem(QString());
        default_font_size->setObjectName(QString::fromUtf8("default_font_size"));

        hboxLayout->addWidget(default_font_size);

        spacerItem1 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem1);


        vboxLayout->addWidget(groupBox_4);

        groupBox_2 = new QGroupBox(LayoutViewConfigPage7);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        hboxLayout1 = new QHBoxLayout(groupBox_2);
        hboxLayout1->setSpacing(6);
        hboxLayout1->setContentsMargins(11, 11, 11, 11);
        hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
        hboxLayout1->setContentsMargins(9, 9, 9, 9);
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        hboxLayout1->addWidget(label_3);

        global_trans = new QComboBox(groupBox_2);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/r0.png"), QSize(), QIcon::Normal, QIcon::Off);
        global_trans->addItem(icon, QString());
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/r90.png"), QSize(), QIcon::Normal, QIcon::Off);
        global_trans->addItem(icon1, QString());
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/r180.png"), QSize(), QIcon::Normal, QIcon::Off);
        global_trans->addItem(icon2, QString());
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/r270.png"), QSize(), QIcon::Normal, QIcon::Off);
        global_trans->addItem(icon3, QString());
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/m0.png"), QSize(), QIcon::Normal, QIcon::Off);
        global_trans->addItem(icon4, QString());
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/m45.png"), QSize(), QIcon::Normal, QIcon::Off);
        global_trans->addItem(icon5, QString());
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/m90.png"), QSize(), QIcon::Normal, QIcon::Off);
        global_trans->addItem(icon6, QString());
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/m135.png"), QSize(), QIcon::Normal, QIcon::Off);
        global_trans->addItem(icon7, QString());
        global_trans->setObjectName(QString::fromUtf8("global_trans"));

        hboxLayout1->addWidget(global_trans);

        spacerItem2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout1->addItem(spacerItem2);


        vboxLayout->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(LayoutViewConfigPage7);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        gridLayout1 = new QGridLayout(groupBox_3);
        gridLayout1->setSpacing(6);
        gridLayout1->setContentsMargins(11, 11, 11, 11);
        gridLayout1->setObjectName(QString::fromUtf8("gridLayout1"));
        gridLayout1->setContentsMargins(9, 9, 9, 9);
        label_13 = new QLabel(groupBox_3);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout1->addWidget(label_13, 0, 0, 1, 1);

        def_depth = new QSpinBox(groupBox_3);
        def_depth->setObjectName(QString::fromUtf8("def_depth"));
        def_depth->setMaximum(1000);

        gridLayout1->addWidget(def_depth, 0, 1, 1, 1);

        spacerItem3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout1->addItem(spacerItem3, 0, 2, 1, 1);

        label_14 = new QLabel(groupBox_3);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setWordWrap(true);

        gridLayout1->addWidget(label_14, 1, 0, 1, 3);


        vboxLayout->addWidget(groupBox_3);


        retranslateUi(LayoutViewConfigPage7);

        QMetaObject::connectSlotsByName(LayoutViewConfigPage7);
    } // setupUi

    void retranslateUi(QFrame *LayoutViewConfigPage7)
    {
        LayoutViewConfigPage7->setWindowTitle(QApplication::translate("LayoutViewConfigPage7", "Application Settings", nullptr));
        groupBox->setTitle(QApplication::translate("LayoutViewConfigPage7", "Oversampling", nullptr));
        label_2->setText(QApplication::translate("LayoutViewConfigPage7", "Use oversampling:  ", nullptr));
        oversampling->setItemText(0, QApplication::translate("LayoutViewConfigPage7", "No oversampling", nullptr));
        oversampling->setItemText(1, QApplication::translate("LayoutViewConfigPage7", "2x oversampling", nullptr));
        oversampling->setItemText(2, QApplication::translate("LayoutViewConfigPage7", "3x oversampling", nullptr));

        label->setText(QApplication::translate("LayoutViewConfigPage7", "Oversampling increases the image quality by using an internal resolution larger than the image resolution. Drawing speed is somewhat reduced and lines may appear thinner.", nullptr));
        groupBox_4->setTitle(QApplication::translate("LayoutViewConfigPage7", "Default Font Size", nullptr));
        label_4->setText(QApplication::translate("LayoutViewConfigPage7", "Font size for \"Default\" font and rulers", nullptr));
        default_font_size->setItemText(0, QApplication::translate("LayoutViewConfigPage7", "Small", nullptr));
        default_font_size->setItemText(1, QApplication::translate("LayoutViewConfigPage7", "Medium", nullptr));
        default_font_size->setItemText(2, QApplication::translate("LayoutViewConfigPage7", "Large", nullptr));

        groupBox_2->setTitle(QApplication::translate("LayoutViewConfigPage7", "Global Transformation", nullptr));
        label_3->setText(QApplication::translate("LayoutViewConfigPage7", "Transform the view globally with", nullptr));
        global_trans->setItemText(0, QApplication::translate("LayoutViewConfigPage7", "(r0)", nullptr));
        global_trans->setItemText(1, QApplication::translate("LayoutViewConfigPage7", "(r90)", nullptr));
        global_trans->setItemText(2, QApplication::translate("LayoutViewConfigPage7", "(r180)", nullptr));
        global_trans->setItemText(3, QApplication::translate("LayoutViewConfigPage7", "(r270)", nullptr));
        global_trans->setItemText(4, QApplication::translate("LayoutViewConfigPage7", "(m0)", nullptr));
        global_trans->setItemText(5, QApplication::translate("LayoutViewConfigPage7", "(m45)", nullptr));
        global_trans->setItemText(6, QApplication::translate("LayoutViewConfigPage7", "(m90)", nullptr));
        global_trans->setItemText(7, QApplication::translate("LayoutViewConfigPage7", "(m135)", nullptr));

        groupBox_3->setTitle(QApplication::translate("LayoutViewConfigPage7", "Hierarchy Depth", nullptr));
        label_13->setText(QApplication::translate("LayoutViewConfigPage7", "Initial hierarchy depth when opening a new panel", nullptr));
        label_14->setText(QApplication::translate("LayoutViewConfigPage7", "(This setting is not active if \"select all hierarchy levels on new cell\" is checked on the \"Navigation/New Cell\" tab)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LayoutViewConfigPage7: public Ui_LayoutViewConfigPage7 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LAYOUTVIEWCONFIGPAGE7_H
