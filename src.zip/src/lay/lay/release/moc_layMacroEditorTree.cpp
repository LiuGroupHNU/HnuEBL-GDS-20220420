/****************************************************************************
** Meta object code from reading C++ file 'layMacroEditorTree.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../layMacroEditorTree.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'layMacroEditorTree.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_lay__MacroTreeModel_t {
    QByteArrayData data[18];
    char stringdata0[231];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__MacroTreeModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__MacroTreeModel_t qt_meta_stringdata_lay__MacroTreeModel = {
    {
QT_MOC_LITERAL(0, 0, 19), // "lay::MacroTreeModel"
QT_MOC_LITERAL(1, 20, 13), // "macro_renamed"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 11), // "lym::Macro*"
QT_MOC_LITERAL(4, 47, 5), // "macro"
QT_MOC_LITERAL(5, 53, 14), // "folder_renamed"
QT_MOC_LITERAL(6, 68, 21), // "lym::MacroCollection*"
QT_MOC_LITERAL(7, 90, 6), // "folder"
QT_MOC_LITERAL(8, 97, 10), // "move_macro"
QT_MOC_LITERAL(9, 108, 6), // "source"
QT_MOC_LITERAL(10, 115, 6), // "target"
QT_MOC_LITERAL(11, 122, 11), // "move_folder"
QT_MOC_LITERAL(12, 134, 13), // "macro_changed"
QT_MOC_LITERAL(13, 148, 13), // "macro_deleted"
QT_MOC_LITERAL(14, 162, 24), // "macro_collection_deleted"
QT_MOC_LITERAL(15, 187, 2), // "mc"
QT_MOC_LITERAL(16, 190, 24), // "macro_collection_changed"
QT_MOC_LITERAL(17, 215, 15) // "about_to_change"

    },
    "lay::MacroTreeModel\0macro_renamed\0\0"
    "lym::Macro*\0macro\0folder_renamed\0"
    "lym::MacroCollection*\0folder\0move_macro\0"
    "source\0target\0move_folder\0macro_changed\0"
    "macro_deleted\0macro_collection_deleted\0"
    "mc\0macro_collection_changed\0about_to_change"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__MacroTreeModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       5,    1,   62,    2, 0x06 /* Public */,
       8,    2,   65,    2, 0x06 /* Public */,
      11,    2,   70,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    0,   75,    2, 0x08 /* Private */,
      13,    1,   76,    2, 0x08 /* Private */,
      14,    1,   79,    2, 0x08 /* Private */,
      16,    0,   82,    2, 0x08 /* Private */,
      17,    0,   83,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 6,    9,   10,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,    9,   10,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,   15,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void lay::MacroTreeModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MacroTreeModel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->macro_renamed((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 1: _t->folder_renamed((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1]))); break;
        case 2: _t->move_macro((*reinterpret_cast< lym::Macro*(*)>(_a[1])),(*reinterpret_cast< lym::MacroCollection*(*)>(_a[2]))); break;
        case 3: _t->move_folder((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1])),(*reinterpret_cast< lym::MacroCollection*(*)>(_a[2]))); break;
        case 4: _t->macro_changed(); break;
        case 5: _t->macro_deleted((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 6: _t->macro_collection_deleted((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1]))); break;
        case 7: _t->macro_collection_changed(); break;
        case 8: _t->about_to_change(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MacroTreeModel::*)(lym::Macro * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroTreeModel::macro_renamed)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MacroTreeModel::*)(lym::MacroCollection * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroTreeModel::folder_renamed)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MacroTreeModel::*)(lym::Macro * , lym::MacroCollection * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroTreeModel::move_macro)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MacroTreeModel::*)(lym::MacroCollection * , lym::MacroCollection * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroTreeModel::move_folder)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject lay::MacroTreeModel::staticMetaObject = { {
    QMetaObject::SuperData::link<QAbstractItemModel::staticMetaObject>(),
    qt_meta_stringdata_lay__MacroTreeModel.data,
    qt_meta_data_lay__MacroTreeModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::MacroTreeModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::MacroTreeModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__MacroTreeModel.stringdata0))
        return static_cast<void*>(this);
    return QAbstractItemModel::qt_metacast(_clname);
}

int lay::MacroTreeModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractItemModel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void lay::MacroTreeModel::macro_renamed(lym::Macro * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void lay::MacroTreeModel::folder_renamed(lym::MacroCollection * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void lay::MacroTreeModel::move_macro(lym::Macro * _t1, lym::MacroCollection * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void lay::MacroTreeModel::move_folder(lym::MacroCollection * _t1, lym::MacroCollection * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
struct qt_meta_stringdata_lay__MacroEditorTree_t {
    QByteArrayData data[22];
    char stringdata0[305];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__MacroEditorTree_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__MacroEditorTree_t qt_meta_stringdata_lay__MacroEditorTree = {
    {
QT_MOC_LITERAL(0, 0, 20), // "lay::MacroEditorTree"
QT_MOC_LITERAL(1, 21, 10), // "move_macro"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 11), // "lym::Macro*"
QT_MOC_LITERAL(4, 45, 6), // "source"
QT_MOC_LITERAL(5, 52, 21), // "lym::MacroCollection*"
QT_MOC_LITERAL(6, 74, 6), // "target"
QT_MOC_LITERAL(7, 81, 11), // "move_folder"
QT_MOC_LITERAL(8, 93, 20), // "macro_double_clicked"
QT_MOC_LITERAL(9, 114, 5), // "macro"
QT_MOC_LITERAL(10, 120, 31), // "macro_collection_double_clicked"
QT_MOC_LITERAL(11, 152, 2), // "mc"
QT_MOC_LITERAL(12, 155, 13), // "macro_renamed"
QT_MOC_LITERAL(13, 169, 14), // "folder_renamed"
QT_MOC_LITERAL(14, 184, 6), // "folder"
QT_MOC_LITERAL(15, 191, 19), // "double_clicked_slot"
QT_MOC_LITERAL(16, 211, 11), // "QModelIndex"
QT_MOC_LITERAL(17, 223, 5), // "index"
QT_MOC_LITERAL(18, 229, 16), // "model_move_macro"
QT_MOC_LITERAL(19, 246, 17), // "model_move_folder"
QT_MOC_LITERAL(20, 264, 19), // "model_macro_renamed"
QT_MOC_LITERAL(21, 284, 20) // "model_folder_renamed"

    },
    "lay::MacroEditorTree\0move_macro\0\0"
    "lym::Macro*\0source\0lym::MacroCollection*\0"
    "target\0move_folder\0macro_double_clicked\0"
    "macro\0macro_collection_double_clicked\0"
    "mc\0macro_renamed\0folder_renamed\0folder\0"
    "double_clicked_slot\0QModelIndex\0index\0"
    "model_move_macro\0model_move_folder\0"
    "model_macro_renamed\0model_folder_renamed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__MacroEditorTree[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   69,    2, 0x06 /* Public */,
       7,    2,   74,    2, 0x06 /* Public */,
       8,    1,   79,    2, 0x06 /* Public */,
      10,    1,   82,    2, 0x06 /* Public */,
      12,    1,   85,    2, 0x06 /* Public */,
      13,    1,   88,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      15,    1,   91,    2, 0x08 /* Private */,
      18,    2,   94,    2, 0x08 /* Private */,
      19,    2,   99,    2, 0x08 /* Private */,
      20,    1,  104,    2, 0x08 /* Private */,
      21,    1,  107,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5,    4,    6,
    QMetaType::Void, 0x80000000 | 5, 0x80000000 | 5,    4,    6,
    QMetaType::Void, 0x80000000 | 3,    9,
    QMetaType::Void, 0x80000000 | 5,   11,
    QMetaType::Void, 0x80000000 | 3,    9,
    QMetaType::Void, 0x80000000 | 5,   14,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5,    4,    6,
    QMetaType::Void, 0x80000000 | 5, 0x80000000 | 5,    4,    6,
    QMetaType::Void, 0x80000000 | 3,    9,
    QMetaType::Void, 0x80000000 | 5,   14,

       0        // eod
};

void lay::MacroEditorTree::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MacroEditorTree *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->move_macro((*reinterpret_cast< lym::Macro*(*)>(_a[1])),(*reinterpret_cast< lym::MacroCollection*(*)>(_a[2]))); break;
        case 1: _t->move_folder((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1])),(*reinterpret_cast< lym::MacroCollection*(*)>(_a[2]))); break;
        case 2: _t->macro_double_clicked((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 3: _t->macro_collection_double_clicked((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1]))); break;
        case 4: _t->macro_renamed((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 5: _t->folder_renamed((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1]))); break;
        case 6: _t->double_clicked_slot((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 7: _t->model_move_macro((*reinterpret_cast< lym::Macro*(*)>(_a[1])),(*reinterpret_cast< lym::MacroCollection*(*)>(_a[2]))); break;
        case 8: _t->model_move_folder((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1])),(*reinterpret_cast< lym::MacroCollection*(*)>(_a[2]))); break;
        case 9: _t->model_macro_renamed((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 10: _t->model_folder_renamed((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MacroEditorTree::*)(lym::Macro * , lym::MacroCollection * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroEditorTree::move_macro)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MacroEditorTree::*)(lym::MacroCollection * , lym::MacroCollection * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroEditorTree::move_folder)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MacroEditorTree::*)(lym::Macro * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroEditorTree::macro_double_clicked)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MacroEditorTree::*)(lym::MacroCollection * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroEditorTree::macro_collection_double_clicked)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (MacroEditorTree::*)(lym::Macro * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroEditorTree::macro_renamed)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (MacroEditorTree::*)(lym::MacroCollection * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MacroEditorTree::folder_renamed)) {
                *result = 5;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject lay::MacroEditorTree::staticMetaObject = { {
    QMetaObject::SuperData::link<QTreeView::staticMetaObject>(),
    qt_meta_stringdata_lay__MacroEditorTree.data,
    qt_meta_data_lay__MacroEditorTree,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::MacroEditorTree::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::MacroEditorTree::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__MacroEditorTree.stringdata0))
        return static_cast<void*>(this);
    return QTreeView::qt_metacast(_clname);
}

int lay::MacroEditorTree::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTreeView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void lay::MacroEditorTree::move_macro(lym::Macro * _t1, lym::MacroCollection * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void lay::MacroEditorTree::move_folder(lym::MacroCollection * _t1, lym::MacroCollection * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void lay::MacroEditorTree::macro_double_clicked(lym::Macro * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void lay::MacroEditorTree::macro_collection_double_clicked(lym::MacroCollection * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void lay::MacroEditorTree::macro_renamed(lym::Macro * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void lay::MacroEditorTree::folder_renamed(lym::MacroCollection * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
