/****************************************************************************
** Meta object code from reading C++ file 'layTechSetupDialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../layTechSetupDialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'layTechSetupDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_lay__TechBaseEditorPage_t {
    QByteArrayData data[4];
    char stringdata0[59];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__TechBaseEditorPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__TechBaseEditorPage_t qt_meta_stringdata_lay__TechBaseEditorPage = {
    {
QT_MOC_LITERAL(0, 0, 23), // "lay::TechBaseEditorPage"
QT_MOC_LITERAL(1, 24, 14), // "browse_clicked"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 18) // "browse_lyp_clicked"

    },
    "lay::TechBaseEditorPage\0browse_clicked\0"
    "\0browse_lyp_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__TechBaseEditorPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   24,    2, 0x08 /* Private */,
       3,    0,   25,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void lay::TechBaseEditorPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TechBaseEditorPage *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->browse_clicked(); break;
        case 1: _t->browse_lyp_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject lay::TechBaseEditorPage::staticMetaObject = { {
    QMetaObject::SuperData::link<TechnologyComponentEditor::staticMetaObject>(),
    qt_meta_stringdata_lay__TechBaseEditorPage.data,
    qt_meta_data_lay__TechBaseEditorPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::TechBaseEditorPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::TechBaseEditorPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__TechBaseEditorPage.stringdata0))
        return static_cast<void*>(this);
    return TechnologyComponentEditor::qt_metacast(_clname);
}

int lay::TechBaseEditorPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = TechnologyComponentEditor::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
struct qt_meta_stringdata_lay__TechMacrosPage_t {
    QByteArrayData data[6];
    char stringdata0[76];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__TechMacrosPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__TechMacrosPage_t qt_meta_stringdata_lay__TechMacrosPage = {
    {
QT_MOC_LITERAL(0, 0, 19), // "lay::TechMacrosPage"
QT_MOC_LITERAL(1, 20, 14), // "macro_selected"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 11), // "QModelIndex"
QT_MOC_LITERAL(4, 48, 5), // "index"
QT_MOC_LITERAL(5, 54, 21) // "create_folder_clicked"

    },
    "lay::TechMacrosPage\0macro_selected\0\0"
    "QModelIndex\0index\0create_folder_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__TechMacrosPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x08 /* Private */,
       5,    0,   27,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,

       0        // eod
};

void lay::TechMacrosPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TechMacrosPage *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->macro_selected((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 1: _t->create_folder_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject lay::TechMacrosPage::staticMetaObject = { {
    QMetaObject::SuperData::link<TechnologyComponentEditor::staticMetaObject>(),
    qt_meta_stringdata_lay__TechMacrosPage.data,
    qt_meta_data_lay__TechMacrosPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::TechMacrosPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::TechMacrosPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__TechMacrosPage.stringdata0))
        return static_cast<void*>(this);
    return TechnologyComponentEditor::qt_metacast(_clname);
}

int lay::TechMacrosPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = TechnologyComponentEditor::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
struct qt_meta_stringdata_lay__TechLoadOptionsEditorPage_t {
    QByteArrayData data[1];
    char stringdata0[31];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__TechLoadOptionsEditorPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__TechLoadOptionsEditorPage_t qt_meta_stringdata_lay__TechLoadOptionsEditorPage = {
    {
QT_MOC_LITERAL(0, 0, 30) // "lay::TechLoadOptionsEditorPage"

    },
    "lay::TechLoadOptionsEditorPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__TechLoadOptionsEditorPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void lay::TechLoadOptionsEditorPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject lay::TechLoadOptionsEditorPage::staticMetaObject = { {
    QMetaObject::SuperData::link<TechnologyComponentEditor::staticMetaObject>(),
    qt_meta_stringdata_lay__TechLoadOptionsEditorPage.data,
    qt_meta_data_lay__TechLoadOptionsEditorPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::TechLoadOptionsEditorPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::TechLoadOptionsEditorPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__TechLoadOptionsEditorPage.stringdata0))
        return static_cast<void*>(this);
    return TechnologyComponentEditor::qt_metacast(_clname);
}

int lay::TechLoadOptionsEditorPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = TechnologyComponentEditor::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_lay__TechSaveOptionsEditorPage_t {
    QByteArrayData data[1];
    char stringdata0[31];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__TechSaveOptionsEditorPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__TechSaveOptionsEditorPage_t qt_meta_stringdata_lay__TechSaveOptionsEditorPage = {
    {
QT_MOC_LITERAL(0, 0, 30) // "lay::TechSaveOptionsEditorPage"

    },
    "lay::TechSaveOptionsEditorPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__TechSaveOptionsEditorPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void lay::TechSaveOptionsEditorPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject lay::TechSaveOptionsEditorPage::staticMetaObject = { {
    QMetaObject::SuperData::link<TechnologyComponentEditor::staticMetaObject>(),
    qt_meta_stringdata_lay__TechSaveOptionsEditorPage.data,
    qt_meta_data_lay__TechSaveOptionsEditorPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::TechSaveOptionsEditorPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::TechSaveOptionsEditorPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__TechSaveOptionsEditorPage.stringdata0))
        return static_cast<void*>(this);
    return TechnologyComponentEditor::qt_metacast(_clname);
}

int lay::TechSaveOptionsEditorPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = TechnologyComponentEditor::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_lay__TechSetupDialog_t {
    QByteArrayData data[12];
    char stringdata0[165];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__TechSetupDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__TechSetupDialog_t qt_meta_stringdata_lay__TechSetupDialog = {
    {
QT_MOC_LITERAL(0, 0, 20), // "lay::TechSetupDialog"
QT_MOC_LITERAL(1, 21, 20), // "current_tech_changed"
QT_MOC_LITERAL(2, 42, 0), // ""
QT_MOC_LITERAL(3, 43, 16), // "QTreeWidgetItem*"
QT_MOC_LITERAL(4, 60, 7), // "current"
QT_MOC_LITERAL(5, 68, 8), // "previous"
QT_MOC_LITERAL(6, 77, 11), // "add_clicked"
QT_MOC_LITERAL(7, 89, 14), // "delete_clicked"
QT_MOC_LITERAL(8, 104, 14), // "rename_clicked"
QT_MOC_LITERAL(9, 119, 14), // "import_clicked"
QT_MOC_LITERAL(10, 134, 14), // "export_clicked"
QT_MOC_LITERAL(11, 149, 15) // "refresh_clicked"

    },
    "lay::TechSetupDialog\0current_tech_changed\0"
    "\0QTreeWidgetItem*\0current\0previous\0"
    "add_clicked\0delete_clicked\0rename_clicked\0"
    "import_clicked\0export_clicked\0"
    "refresh_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__TechSetupDialog[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   49,    2, 0x09 /* Protected */,
       6,    0,   54,    2, 0x09 /* Protected */,
       7,    0,   55,    2, 0x09 /* Protected */,
       8,    0,   56,    2, 0x09 /* Protected */,
       9,    0,   57,    2, 0x09 /* Protected */,
      10,    0,   58,    2, 0x09 /* Protected */,
      11,    0,   59,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3,    4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void lay::TechSetupDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TechSetupDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->current_tech_changed((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< QTreeWidgetItem*(*)>(_a[2]))); break;
        case 1: _t->add_clicked(); break;
        case 2: _t->delete_clicked(); break;
        case 3: _t->rename_clicked(); break;
        case 4: _t->import_clicked(); break;
        case 5: _t->export_clicked(); break;
        case 6: _t->refresh_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject lay::TechSetupDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_lay__TechSetupDialog.data,
    qt_meta_data_lay__TechSetupDialog,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::TechSetupDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::TechSetupDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__TechSetupDialog.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int lay::TechSetupDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
