/********************************************************************************
** Form generated from reading UI file 'MainConfigPage3.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINCONFIGPAGE3_H
#define UI_MAINCONFIGPAGE3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_MainConfigPage3
{
public:
    QVBoxLayout *vboxLayout;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QLabel *textLabel1_4;
    QLineEdit *grids_edit;
    QLabel *textLabel1;

    void setupUi(QFrame *MainConfigPage3)
    {
        if (MainConfigPage3->objectName().isEmpty())
            MainConfigPage3->setObjectName(QString::fromUtf8("MainConfigPage3"));
        MainConfigPage3->resize(475, 81);
        vboxLayout = new QVBoxLayout(MainConfigPage3);
        vboxLayout->setSpacing(6);
        vboxLayout->setContentsMargins(9, 9, 9, 9);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        groupBox = new QGroupBox(MainConfigPage3);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(9, 9, 9, 9);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        textLabel1_4 = new QLabel(groupBox);
        textLabel1_4->setObjectName(QString::fromUtf8("textLabel1_4"));

        gridLayout->addWidget(textLabel1_4, 0, 2, 1, 1);

        grids_edit = new QLineEdit(groupBox);
        grids_edit->setObjectName(QString::fromUtf8("grids_edit"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(grids_edit->sizePolicy().hasHeightForWidth());
        grids_edit->setSizePolicy(sizePolicy);

        gridLayout->addWidget(grids_edit, 0, 1, 1, 1);

        textLabel1 = new QLabel(groupBox);
        textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(textLabel1->sizePolicy().hasHeightForWidth());
        textLabel1->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(textLabel1, 0, 0, 1, 1);


        vboxLayout->addWidget(groupBox);


        retranslateUi(MainConfigPage3);

        QMetaObject::connectSlotsByName(MainConfigPage3);
    } // setupUi

    void retranslateUi(QFrame *MainConfigPage3)
    {
        MainConfigPage3->setWindowTitle(QCoreApplication::translate("MainConfigPage3", "Settings", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainConfigPage3", "Default Grids", nullptr));
        textLabel1_4->setText(QCoreApplication::translate("MainConfigPage3", "\302\265m (g1,g2,...)", nullptr));
        textLabel1->setText(QCoreApplication::translate("MainConfigPage3", "Grids for \"View\" menu", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainConfigPage3: public Ui_MainConfigPage3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINCONFIGPAGE3_H
