class NewSampleLibraryClass

  def initialize
    # TODO: add your code here
  end

end
