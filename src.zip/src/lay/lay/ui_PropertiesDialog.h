/********************************************************************************
** Form generated from reading UI file 'PropertiesDialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROPERTIESDIALOG_H
#define UI_PROPERTIESDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_PropertiesDialog
{
public:
    QVBoxLayout *vboxLayout;
    QFrame *content_frame;
    QFrame *frame;
    QHBoxLayout *hboxLayout;
    QPushButton *prev_button;
    QPushButton *next_button;
    QSpacerItem *horizontalSpacer;
    QCheckBox *apply_to_all_cbx;
    QCheckBox *relative_cbx;
    QSpacerItem *spacerItem;
    QPushButton *ok_button;
    QPushButton *cancel_button;

    void setupUi(QDialog *PropertiesDialog)
    {
        if (PropertiesDialog->objectName().isEmpty())
            PropertiesDialog->setObjectName(QString::fromUtf8("PropertiesDialog"));
        PropertiesDialog->resize(601, 391);
        vboxLayout = new QVBoxLayout(PropertiesDialog);
        vboxLayout->setSpacing(6);
        vboxLayout->setContentsMargins(11, 11, 11, 11);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        vboxLayout->setContentsMargins(9, 9, 9, 9);
        content_frame = new QFrame(PropertiesDialog);
        content_frame->setObjectName(QString::fromUtf8("content_frame"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(content_frame->sizePolicy().hasHeightForWidth());
        content_frame->setSizePolicy(sizePolicy);
        content_frame->setFrameShape(QFrame::StyledPanel);
        content_frame->setFrameShadow(QFrame::Raised);

        vboxLayout->addWidget(content_frame);

        frame = new QFrame(PropertiesDialog);
        frame->setObjectName(QString::fromUtf8("frame"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy1);
        frame->setFrameShape(QFrame::NoFrame);
        frame->setFrameShadow(QFrame::Raised);
        hboxLayout = new QHBoxLayout(frame);
        hboxLayout->setSpacing(6);
        hboxLayout->setContentsMargins(11, 11, 11, 11);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        prev_button = new QPushButton(frame);
        prev_button->setObjectName(QString::fromUtf8("prev_button"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Ignored);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(prev_button->sizePolicy().hasHeightForWidth());
        prev_button->setSizePolicy(sizePolicy2);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/left.png"), QSize(), QIcon::Normal, QIcon::Off);
        prev_button->setIcon(icon);

        hboxLayout->addWidget(prev_button);

        next_button = new QPushButton(frame);
        next_button->setObjectName(QString::fromUtf8("next_button"));
        sizePolicy2.setHeightForWidth(next_button->sizePolicy().hasHeightForWidth());
        next_button->setSizePolicy(sizePolicy2);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/right.png"), QSize(), QIcon::Normal, QIcon::Off);
        next_button->setIcon(icon1);

        hboxLayout->addWidget(next_button);

        horizontalSpacer = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        hboxLayout->addItem(horizontalSpacer);

        apply_to_all_cbx = new QCheckBox(frame);
        apply_to_all_cbx->setObjectName(QString::fromUtf8("apply_to_all_cbx"));

        hboxLayout->addWidget(apply_to_all_cbx);

        relative_cbx = new QCheckBox(frame);
        relative_cbx->setObjectName(QString::fromUtf8("relative_cbx"));
        relative_cbx->setEnabled(false);

        hboxLayout->addWidget(relative_cbx);

        spacerItem = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem);

        ok_button = new QPushButton(frame);
        ok_button->setObjectName(QString::fromUtf8("ok_button"));

        hboxLayout->addWidget(ok_button);

        cancel_button = new QPushButton(frame);
        cancel_button->setObjectName(QString::fromUtf8("cancel_button"));

        hboxLayout->addWidget(cancel_button);


        vboxLayout->addWidget(frame);


        retranslateUi(PropertiesDialog);
        QObject::connect(apply_to_all_cbx, SIGNAL(toggled(bool)), relative_cbx, SLOT(setEnabled(bool)));

        prev_button->setDefault(false);
        next_button->setDefault(false);
        ok_button->setDefault(true);


        QMetaObject::connectSlotsByName(PropertiesDialog);
    } // setupUi

    void retranslateUi(QDialog *PropertiesDialog)
    {
        PropertiesDialog->setWindowTitle(QApplication::translate("PropertiesDialog", "Object Properties", nullptr));
        prev_button->setText(QApplication::translate("PropertiesDialog", "Previous", nullptr));
        next_button->setText(QApplication::translate("PropertiesDialog", "Next", nullptr));
        apply_to_all_cbx->setText(QApplication::translate("PropertiesDialog", "Change all", nullptr));
        relative_cbx->setText(QApplication::translate("PropertiesDialog", "Relative", nullptr));
        ok_button->setText(QApplication::translate("PropertiesDialog", "Ok", nullptr));
        cancel_button->setText(QApplication::translate("PropertiesDialog", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PropertiesDialog: public Ui_PropertiesDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROPERTIESDIALOG_H
