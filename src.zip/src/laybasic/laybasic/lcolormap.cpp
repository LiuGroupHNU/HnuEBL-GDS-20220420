#include "lcolormap.h"
#include <QPainter>
#include <QDebug>
LColorMap::LColorMap(QWidget *parent) : QWidget(parent)
{
    // 计算colors
    float colorBarLength = 343.0;
    float tempLength=colorBarLength/4;
    QColor color;
    for(int i=0;i<tempLength/2;i++)// jet
    {
        color.setRgbF(0,0,(tempLength/2+i)/tempLength);
        colors.push_back(color);
    }
    for(int i=tempLength/2+1;i<tempLength/2+tempLength;i++)// jet
    {
        color.setRgbF(0,(i-tempLength/2)/tempLength,1);
        colors.push_back(color);
    }
    for(int i=tempLength/2+tempLength+1;i<tempLength/2+2*tempLength;i++)// jet
    {
        color.setRgbF((i-tempLength-tempLength/2)/tempLength,1,(tempLength*2+tempLength/2-i)/tempLength);
        colors.push_back(color);
    }
    for(int i=tempLength/2+2*tempLength+1;i<tempLength/2+3*tempLength;i++)// jet
    {
        color.setRgbF(1,(tempLength*3+tempLength/2-i)/tempLength,0);
        colors.push_back(color);
    }
    for(int i=tempLength/2+3*tempLength+1;i<colorBarLength;i++)// jet
    {
        color.setRgbF((colorBarLength-i+tempLength/2)/(tempLength),0,0);
        if (color == QColor(0,0,0))
            qDebug()<<"black color";
        colors.push_back(color);
    }
    qDebug()<<"colors's num: "<<colors.size();
}

void LColorMap::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    if (height() < 343)
        return;
    for (int i =0 ;i<343;i++) {
        QRect rect(0,343-i + 20,20,1);
        painter.fillRect(rect,colors.at(i));
    }
    for (int i = 0;i < 6;i++) {
        QString strValue;
        strValue.sprintf("%.2f",min+i*(max-min)/5);
        QFont font;
        font.setFamily("Microsoft YaHei");
        font.setPointSize(8);
        QFontMetrics fm(font);
        QRect rec = fm.boundingRect(strValue);
        //字符串所占的像素宽度,高度
        int textWidth = rec.width();
        int textHeight = rec.height();
        QRect textRect(25,343 +textHeight  - (343/5)*i,textWidth+20,textHeight);
        painter.drawText(textRect,strValue);
    }
}


void LColorMap::setMinMax(double min,double max)
{
    this->min = min;
    this->max = max;
    update();
}

QColor LColorMap::getColor(double value)
{
    if (value > max || value <min)
        return QColor(0,0,0);
    if (max == min)
    return QColor (255,0,0);
    if(value == max)
    {
        return colors.at(342);
    }
    int index = ((value-min)/(max-min))*343;
    return colors.at(index);
}
