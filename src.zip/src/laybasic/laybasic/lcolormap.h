#ifndef LCOLORMAP_H
#define LCOLORMAP_H

#include <QWidget>

class LColorMap : public QWidget
{
    Q_OBJECT
public:
    explicit LColorMap(QWidget *parent = nullptr);
    QColor getColor(double value);
protected:
    void paintEvent(QPaintEvent *event) override;
signals:

public slots:
    void setMinMax(double min,double max);
private:
    QVector<QColor> colors;// 颜色数组
    double min = 0;
    double max = 100;
};

#endif // LCOLORMAP_H
