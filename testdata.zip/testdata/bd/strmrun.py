import pya
print("Hello, world " + str(pya.DBox(0, 0, 42, -42)) + "!")
