# encoding: UTF-8

# KLayout Layout Viewer
# Copyright (C) 2006-2022 Matthias Koefferlein
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

if !$:.member?(File::dirname($0))
  $:.push(File::dirname($0))
end

load("test_prologue.rb")

# NOTE: for some mysterious reason the tests work better on Ruby 2.3.x if the actual test 
# implementation is in a file of it's own (maybe: VM forces a context release on "load").
# Without this, the GC-dependent tests tend to not release objects that are supposed 
# to be cleaned up.
load("basic_testcore.rb")

load("test_epilogue.rb")

