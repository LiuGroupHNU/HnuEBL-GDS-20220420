
def f
  return "f: " + File.basename(__FILE__) + ":" + __LINE__.to_s
end

