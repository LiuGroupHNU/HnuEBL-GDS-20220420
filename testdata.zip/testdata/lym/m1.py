
print("Hello, world!")
