
puts "Stop 1: " + File.basename(__FILE__) + ":" + __LINE__.to_s

# %include a_inc.rb

puts f

puts "Stop 2: " + File.basename(__FILE__) + ":" + __LINE__.to_s

