
def f
  raise("An error")
end

