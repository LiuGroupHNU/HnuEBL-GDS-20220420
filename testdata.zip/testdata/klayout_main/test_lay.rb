
puts RBA::LayoutView::current.active_cellview.layout.top_cell.name

