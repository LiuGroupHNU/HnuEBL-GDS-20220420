
puts RBA::Expression::new("to_i(tv1)+to_i(tv2)").eval
puts RBA::Expression::new("tv3").eval

