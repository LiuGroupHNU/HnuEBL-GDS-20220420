
puts "Variable v1=#{$v1} v2=#{$v2}"

