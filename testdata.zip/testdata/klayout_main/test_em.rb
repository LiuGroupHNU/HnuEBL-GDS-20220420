
puts RBA::Application.instance.is_editable?.inspect

