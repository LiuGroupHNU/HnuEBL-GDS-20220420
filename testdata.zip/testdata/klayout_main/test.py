
print("Variable v1="+str(v1)+" v2="+str(v2))

