
RBA::Application.instance.set_config("key4test", "42")

