
puts RBA::Application.instance.get_config("key4test")

