class NewSampleLibraryClass(object):

  def __init__(self):
    # TODO: add your code here
    pass

