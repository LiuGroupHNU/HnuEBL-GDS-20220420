/****************************************************************************
** Meta object code from reading C++ file 'layMacroEditorDialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../layMacroEditorDialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'layMacroEditorDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_lay__MacroEditorDialog_t {
    QByteArrayData data[79];
    char stringdata0[1305];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__MacroEditorDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__MacroEditorDialog_t qt_meta_stringdata_lay__MacroEditorDialog = {
    {
QT_MOC_LITERAL(0, 0, 22), // "lay::MacroEditorDialog"
QT_MOC_LITERAL(1, 23, 7), // "refresh"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 19), // "help_button_clicked"
QT_MOC_LITERAL(4, 52, 18), // "add_button_clicked"
QT_MOC_LITERAL(5, 71, 20), // "close_button_clicked"
QT_MOC_LITERAL(6, 92, 21), // "delete_button_clicked"
QT_MOC_LITERAL(7, 114, 21), // "rename_button_clicked"
QT_MOC_LITERAL(8, 136, 21), // "import_button_clicked"
QT_MOC_LITERAL(9, 158, 25), // "new_folder_button_clicked"
QT_MOC_LITERAL(10, 184, 23), // "save_all_button_clicked"
QT_MOC_LITERAL(11, 208, 19), // "save_button_clicked"
QT_MOC_LITERAL(12, 228, 22), // "save_as_button_clicked"
QT_MOC_LITERAL(13, 251, 18), // "run_button_clicked"
QT_MOC_LITERAL(14, 270, 23), // "run_this_button_clicked"
QT_MOC_LITERAL(15, 294, 26), // "single_step_button_clicked"
QT_MOC_LITERAL(16, 321, 24), // "next_step_button_clicked"
QT_MOC_LITERAL(17, 346, 20), // "pause_button_clicked"
QT_MOC_LITERAL(18, 367, 19), // "stop_button_clicked"
QT_MOC_LITERAL(19, 387, 25), // "properties_button_clicked"
QT_MOC_LITERAL(20, 413, 20), // "setup_button_clicked"
QT_MOC_LITERAL(21, 434, 25), // "breakpoint_button_clicked"
QT_MOC_LITERAL(22, 460, 12), // "add_location"
QT_MOC_LITERAL(23, 473, 15), // "remove_location"
QT_MOC_LITERAL(24, 489, 32), // "clear_breakpoints_button_clicked"
QT_MOC_LITERAL(25, 522, 19), // "item_double_clicked"
QT_MOC_LITERAL(26, 542, 11), // "lym::Macro*"
QT_MOC_LITERAL(27, 554, 5), // "macro"
QT_MOC_LITERAL(28, 560, 10), // "move_macro"
QT_MOC_LITERAL(29, 571, 6), // "source"
QT_MOC_LITERAL(30, 578, 21), // "lym::MacroCollection*"
QT_MOC_LITERAL(31, 600, 6), // "target"
QT_MOC_LITERAL(32, 607, 11), // "move_folder"
QT_MOC_LITERAL(33, 619, 13), // "macro_renamed"
QT_MOC_LITERAL(34, 633, 14), // "folder_renamed"
QT_MOC_LITERAL(35, 648, 2), // "mc"
QT_MOC_LITERAL(36, 651, 19), // "current_tab_changed"
QT_MOC_LITERAL(37, 671, 5), // "index"
QT_MOC_LITERAL(38, 677, 6), // "commit"
QT_MOC_LITERAL(39, 684, 28), // "stack_element_double_clicked"
QT_MOC_LITERAL(40, 713, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(41, 730, 4), // "item"
QT_MOC_LITERAL(42, 735, 13), // "search_edited"
QT_MOC_LITERAL(43, 749, 14), // "search_editing"
QT_MOC_LITERAL(44, 764, 15), // "search_finished"
QT_MOC_LITERAL(45, 780, 19), // "tab_close_requested"
QT_MOC_LITERAL(46, 800, 27), // "replace_mode_button_clicked"
QT_MOC_LITERAL(47, 828, 27), // "replace_next_button_clicked"
QT_MOC_LITERAL(48, 856, 26), // "replace_all_button_clicked"
QT_MOC_LITERAL(49, 883, 24), // "find_next_button_clicked"
QT_MOC_LITERAL(50, 908, 24), // "find_prev_button_clicked"
QT_MOC_LITERAL(51, 933, 14), // "help_requested"
QT_MOC_LITERAL(52, 948, 1), // "s"
QT_MOC_LITERAL(53, 950, 16), // "search_requested"
QT_MOC_LITERAL(54, 967, 13), // "macro_changed"
QT_MOC_LITERAL(55, 981, 13), // "macro_deleted"
QT_MOC_LITERAL(56, 995, 24), // "macro_collection_deleted"
QT_MOC_LITERAL(57, 1020, 10), // "collection"
QT_MOC_LITERAL(58, 1031, 24), // "macro_collection_changed"
QT_MOC_LITERAL(59, 1056, 9), // "add_watch"
QT_MOC_LITERAL(60, 1066, 10), // "edit_watch"
QT_MOC_LITERAL(61, 1077, 11), // "del_watches"
QT_MOC_LITERAL(62, 1089, 13), // "clear_watches"
QT_MOC_LITERAL(63, 1103, 16), // "set_debugging_on"
QT_MOC_LITERAL(64, 1120, 2), // "on"
QT_MOC_LITERAL(65, 1123, 7), // "forward"
QT_MOC_LITERAL(66, 1131, 8), // "backward"
QT_MOC_LITERAL(67, 1140, 14), // "add_edit_trace"
QT_MOC_LITERAL(68, 1155, 8), // "compress"
QT_MOC_LITERAL(69, 1164, 16), // "clear_edit_trace"
QT_MOC_LITERAL(70, 1181, 18), // "file_changed_timer"
QT_MOC_LITERAL(71, 1200, 30), // "immediate_command_text_changed"
QT_MOC_LITERAL(72, 1231, 4), // "text"
QT_MOC_LITERAL(73, 1236, 12), // "file_changed"
QT_MOC_LITERAL(74, 1249, 4), // "path"
QT_MOC_LITERAL(75, 1254, 12), // "file_removed"
QT_MOC_LITERAL(76, 1267, 9), // "clear_log"
QT_MOC_LITERAL(77, 1277, 14), // "search_replace"
QT_MOC_LITERAL(78, 1292, 12) // "apply_search"

    },
    "lay::MacroEditorDialog\0refresh\0\0"
    "help_button_clicked\0add_button_clicked\0"
    "close_button_clicked\0delete_button_clicked\0"
    "rename_button_clicked\0import_button_clicked\0"
    "new_folder_button_clicked\0"
    "save_all_button_clicked\0save_button_clicked\0"
    "save_as_button_clicked\0run_button_clicked\0"
    "run_this_button_clicked\0"
    "single_step_button_clicked\0"
    "next_step_button_clicked\0pause_button_clicked\0"
    "stop_button_clicked\0properties_button_clicked\0"
    "setup_button_clicked\0breakpoint_button_clicked\0"
    "add_location\0remove_location\0"
    "clear_breakpoints_button_clicked\0"
    "item_double_clicked\0lym::Macro*\0macro\0"
    "move_macro\0source\0lym::MacroCollection*\0"
    "target\0move_folder\0macro_renamed\0"
    "folder_renamed\0mc\0current_tab_changed\0"
    "index\0commit\0stack_element_double_clicked\0"
    "QListWidgetItem*\0item\0search_edited\0"
    "search_editing\0search_finished\0"
    "tab_close_requested\0replace_mode_button_clicked\0"
    "replace_next_button_clicked\0"
    "replace_all_button_clicked\0"
    "find_next_button_clicked\0"
    "find_prev_button_clicked\0help_requested\0"
    "s\0search_requested\0macro_changed\0"
    "macro_deleted\0macro_collection_deleted\0"
    "collection\0macro_collection_changed\0"
    "add_watch\0edit_watch\0del_watches\0"
    "clear_watches\0set_debugging_on\0on\0"
    "forward\0backward\0add_edit_trace\0"
    "compress\0clear_edit_trace\0file_changed_timer\0"
    "immediate_command_text_changed\0text\0"
    "file_changed\0path\0file_removed\0clear_log\0"
    "search_replace\0apply_search"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__MacroEditorDialog[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      62,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  324,    2, 0x0a /* Public */,
       3,    0,  325,    2, 0x08 /* Private */,
       4,    0,  326,    2, 0x08 /* Private */,
       5,    0,  327,    2, 0x08 /* Private */,
       6,    0,  328,    2, 0x08 /* Private */,
       7,    0,  329,    2, 0x08 /* Private */,
       8,    0,  330,    2, 0x08 /* Private */,
       9,    0,  331,    2, 0x08 /* Private */,
      10,    0,  332,    2, 0x08 /* Private */,
      11,    0,  333,    2, 0x08 /* Private */,
      12,    0,  334,    2, 0x08 /* Private */,
      13,    0,  335,    2, 0x08 /* Private */,
      14,    0,  336,    2, 0x08 /* Private */,
      15,    0,  337,    2, 0x08 /* Private */,
      16,    0,  338,    2, 0x08 /* Private */,
      17,    0,  339,    2, 0x08 /* Private */,
      18,    0,  340,    2, 0x08 /* Private */,
      19,    0,  341,    2, 0x08 /* Private */,
      20,    0,  342,    2, 0x08 /* Private */,
      21,    0,  343,    2, 0x08 /* Private */,
      22,    0,  344,    2, 0x08 /* Private */,
      23,    0,  345,    2, 0x08 /* Private */,
      24,    0,  346,    2, 0x08 /* Private */,
      25,    1,  347,    2, 0x08 /* Private */,
      28,    2,  350,    2, 0x08 /* Private */,
      32,    2,  355,    2, 0x08 /* Private */,
      33,    1,  360,    2, 0x08 /* Private */,
      34,    1,  363,    2, 0x08 /* Private */,
      36,    1,  366,    2, 0x08 /* Private */,
      38,    0,  369,    2, 0x08 /* Private */,
      39,    1,  370,    2, 0x08 /* Private */,
      42,    0,  373,    2, 0x08 /* Private */,
      43,    0,  374,    2, 0x08 /* Private */,
      44,    0,  375,    2, 0x08 /* Private */,
      45,    1,  376,    2, 0x08 /* Private */,
      46,    0,  379,    2, 0x08 /* Private */,
      47,    0,  380,    2, 0x08 /* Private */,
      48,    0,  381,    2, 0x08 /* Private */,
      49,    0,  382,    2, 0x08 /* Private */,
      50,    0,  383,    2, 0x08 /* Private */,
      51,    1,  384,    2, 0x08 /* Private */,
      53,    1,  387,    2, 0x08 /* Private */,
      54,    1,  390,    2, 0x08 /* Private */,
      55,    1,  393,    2, 0x08 /* Private */,
      56,    1,  396,    2, 0x08 /* Private */,
      58,    1,  399,    2, 0x08 /* Private */,
      59,    0,  402,    2, 0x08 /* Private */,
      60,    0,  403,    2, 0x08 /* Private */,
      61,    0,  404,    2, 0x08 /* Private */,
      62,    0,  405,    2, 0x08 /* Private */,
      63,    1,  406,    2, 0x08 /* Private */,
      65,    0,  409,    2, 0x08 /* Private */,
      66,    0,  410,    2, 0x08 /* Private */,
      67,    1,  411,    2, 0x08 /* Private */,
      69,    0,  414,    2, 0x08 /* Private */,
      70,    0,  415,    2, 0x09 /* Protected */,
      71,    1,  416,    2, 0x09 /* Protected */,
      73,    1,  419,    2, 0x09 /* Protected */,
      75,    1,  422,    2, 0x09 /* Protected */,
      76,    0,  425,    2, 0x09 /* Protected */,
      77,    0,  426,    2, 0x09 /* Protected */,
      78,    0,  427,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 26,   27,
    QMetaType::Void, 0x80000000 | 26, 0x80000000 | 30,   29,   31,
    QMetaType::Void, 0x80000000 | 30, 0x80000000 | 30,   29,   31,
    QMetaType::Void, 0x80000000 | 26,   27,
    QMetaType::Void, 0x80000000 | 30,   35,
    QMetaType::Void, QMetaType::Int,   37,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 40,   41,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   52,
    QMetaType::Void, QMetaType::QString,   52,
    QMetaType::Void, 0x80000000 | 26,   27,
    QMetaType::Void, 0x80000000 | 26,   27,
    QMetaType::Void, 0x80000000 | 30,   57,
    QMetaType::Void, 0x80000000 | 30,   57,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   64,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   68,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   72,
    QMetaType::Void, QMetaType::QString,   74,
    QMetaType::Void, QMetaType::QString,   74,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void lay::MacroEditorDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MacroEditorDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->refresh(); break;
        case 1: _t->help_button_clicked(); break;
        case 2: _t->add_button_clicked(); break;
        case 3: _t->close_button_clicked(); break;
        case 4: _t->delete_button_clicked(); break;
        case 5: _t->rename_button_clicked(); break;
        case 6: _t->import_button_clicked(); break;
        case 7: _t->new_folder_button_clicked(); break;
        case 8: _t->save_all_button_clicked(); break;
        case 9: _t->save_button_clicked(); break;
        case 10: _t->save_as_button_clicked(); break;
        case 11: _t->run_button_clicked(); break;
        case 12: _t->run_this_button_clicked(); break;
        case 13: _t->single_step_button_clicked(); break;
        case 14: _t->next_step_button_clicked(); break;
        case 15: _t->pause_button_clicked(); break;
        case 16: _t->stop_button_clicked(); break;
        case 17: _t->properties_button_clicked(); break;
        case 18: _t->setup_button_clicked(); break;
        case 19: _t->breakpoint_button_clicked(); break;
        case 20: _t->add_location(); break;
        case 21: _t->remove_location(); break;
        case 22: _t->clear_breakpoints_button_clicked(); break;
        case 23: _t->item_double_clicked((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 24: _t->move_macro((*reinterpret_cast< lym::Macro*(*)>(_a[1])),(*reinterpret_cast< lym::MacroCollection*(*)>(_a[2]))); break;
        case 25: _t->move_folder((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1])),(*reinterpret_cast< lym::MacroCollection*(*)>(_a[2]))); break;
        case 26: _t->macro_renamed((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 27: _t->folder_renamed((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1]))); break;
        case 28: _t->current_tab_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->commit(); break;
        case 30: _t->stack_element_double_clicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 31: _t->search_edited(); break;
        case 32: _t->search_editing(); break;
        case 33: _t->search_finished(); break;
        case 34: _t->tab_close_requested((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: _t->replace_mode_button_clicked(); break;
        case 36: _t->replace_next_button_clicked(); break;
        case 37: _t->replace_all_button_clicked(); break;
        case 38: _t->find_next_button_clicked(); break;
        case 39: _t->find_prev_button_clicked(); break;
        case 40: _t->help_requested((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 41: _t->search_requested((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 42: _t->macro_changed((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 43: _t->macro_deleted((*reinterpret_cast< lym::Macro*(*)>(_a[1]))); break;
        case 44: _t->macro_collection_deleted((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1]))); break;
        case 45: _t->macro_collection_changed((*reinterpret_cast< lym::MacroCollection*(*)>(_a[1]))); break;
        case 46: _t->add_watch(); break;
        case 47: _t->edit_watch(); break;
        case 48: _t->del_watches(); break;
        case 49: _t->clear_watches(); break;
        case 50: _t->set_debugging_on((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 51: _t->forward(); break;
        case 52: _t->backward(); break;
        case 53: _t->add_edit_trace((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 54: _t->clear_edit_trace(); break;
        case 55: _t->file_changed_timer(); break;
        case 56: _t->immediate_command_text_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 57: _t->file_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 58: _t->file_removed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 59: _t->clear_log(); break;
        case 60: _t->search_replace(); break;
        case 61: _t->apply_search(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 23:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 24:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 25:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 26:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 27:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 42:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 43:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::Macro* >(); break;
            }
            break;
        case 44:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        case 45:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< lym::MacroCollection* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject lay::MacroEditorDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_lay__MacroEditorDialog.data,
    qt_meta_data_lay__MacroEditorDialog,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::MacroEditorDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::MacroEditorDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__MacroEditorDialog.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "lay::Plugin"))
        return static_cast< lay::Plugin*>(this);
    if (!strcmp(_clname, "gsi::Console"))
        return static_cast< gsi::Console*>(this);
    if (!strcmp(_clname, "gsi::ExecutionHandler"))
        return static_cast< gsi::ExecutionHandler*>(this);
    return QDialog::qt_metacast(_clname);
}

int lay::MacroEditorDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 62)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 62;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 62)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 62;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
