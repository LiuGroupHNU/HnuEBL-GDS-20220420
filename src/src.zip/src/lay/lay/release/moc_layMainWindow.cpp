/****************************************************************************
** Meta object code from reading C++ file 'layMainWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../layMainWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'layMainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_lay__MainWindow_t {
    QByteArrayData data[44];
    char stringdata0[528];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__MainWindow_t qt_meta_stringdata_lay__MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 15), // "lay::MainWindow"
QT_MOC_LITERAL(1, 16, 6), // "closed"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 11), // "current_pos"
QT_MOC_LITERAL(4, 36, 1), // "x"
QT_MOC_LITERAL(5, 38, 1), // "y"
QT_MOC_LITERAL(6, 40, 9), // "dbu_units"
QT_MOC_LITERAL(7, 50, 17), // "clear_current_pos"
QT_MOC_LITERAL(8, 68, 7), // "message"
QT_MOC_LITERAL(9, 76, 11), // "std::string"
QT_MOC_LITERAL(10, 88, 1), // "s"
QT_MOC_LITERAL(11, 90, 2), // "ms"
QT_MOC_LITERAL(12, 93, 13), // "clear_message"
QT_MOC_LITERAL(13, 107, 11), // "select_mode"
QT_MOC_LITERAL(14, 119, 1), // "m"
QT_MOC_LITERAL(15, 121, 20), // "update_action_states"
QT_MOC_LITERAL(16, 142, 6), // "cancel"
QT_MOC_LITERAL(17, 149, 6), // "redraw"
QT_MOC_LITERAL(18, 156, 4), // "exit"
QT_MOC_LITERAL(19, 161, 18), // "close_current_view"
QT_MOC_LITERAL(20, 180, 10), // "close_view"
QT_MOC_LITERAL(21, 191, 5), // "index"
QT_MOC_LITERAL(22, 197, 19), // "tab_close_requested"
QT_MOC_LITERAL(23, 217, 11), // "open_recent"
QT_MOC_LITERAL(24, 229, 6), // "size_t"
QT_MOC_LITERAL(25, 236, 1), // "n"
QT_MOC_LITERAL(26, 238, 19), // "open_recent_session"
QT_MOC_LITERAL(27, 258, 28), // "open_recent_layer_properties"
QT_MOC_LITERAL(28, 287, 21), // "open_recent_bookmarks"
QT_MOC_LITERAL(29, 309, 13), // "view_selected"
QT_MOC_LITERAL(30, 323, 18), // "view_title_changed"
QT_MOC_LITERAL(31, 342, 9), // "show_help"
QT_MOC_LITERAL(32, 352, 3), // "url"
QT_MOC_LITERAL(33, 356, 15), // "show_modal_help"
QT_MOC_LITERAL(34, 372, 30), // "dock_widget_visibility_changed"
QT_MOC_LITERAL(35, 403, 7), // "visible"
QT_MOC_LITERAL(36, 411, 12), // "menu_changed"
QT_MOC_LITERAL(37, 424, 13), // "message_timer"
QT_MOC_LITERAL(38, 438, 21), // "edits_enabled_changed"
QT_MOC_LITERAL(39, 460, 17), // "menu_needs_update"
QT_MOC_LITERAL(40, 478, 18), // "file_changed_timer"
QT_MOC_LITERAL(41, 497, 12), // "file_changed"
QT_MOC_LITERAL(42, 510, 4), // "path"
QT_MOC_LITERAL(43, 515, 12) // "file_removed"

    },
    "lay::MainWindow\0closed\0\0current_pos\0"
    "x\0y\0dbu_units\0clear_current_pos\0message\0"
    "std::string\0s\0ms\0clear_message\0"
    "select_mode\0m\0update_action_states\0"
    "cancel\0redraw\0exit\0close_current_view\0"
    "close_view\0index\0tab_close_requested\0"
    "open_recent\0size_t\0n\0open_recent_session\0"
    "open_recent_layer_properties\0"
    "open_recent_bookmarks\0view_selected\0"
    "view_title_changed\0show_help\0url\0"
    "show_modal_help\0dock_widget_visibility_changed\0"
    "visible\0menu_changed\0message_timer\0"
    "edits_enabled_changed\0menu_needs_update\0"
    "file_changed_timer\0file_changed\0path\0"
    "file_removed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  159,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    3,  160,    2, 0x0a /* Public */,
       7,    0,  167,    2, 0x0a /* Public */,
       8,    2,  168,    2, 0x0a /* Public */,
      12,    0,  173,    2, 0x0a /* Public */,
      13,    1,  174,    2, 0x0a /* Public */,
      15,    0,  177,    2, 0x0a /* Public */,
      16,    0,  178,    2, 0x0a /* Public */,
      17,    0,  179,    2, 0x0a /* Public */,
      18,    0,  180,    2, 0x0a /* Public */,
      19,    0,  181,    2, 0x0a /* Public */,
      20,    1,  182,    2, 0x0a /* Public */,
      22,    1,  185,    2, 0x0a /* Public */,
      23,    1,  188,    2, 0x0a /* Public */,
      26,    1,  191,    2, 0x0a /* Public */,
      27,    1,  194,    2, 0x0a /* Public */,
      28,    1,  197,    2, 0x0a /* Public */,
      29,    1,  200,    2, 0x0a /* Public */,
      30,    0,  203,    2, 0x0a /* Public */,
      31,    1,  204,    2, 0x0a /* Public */,
      33,    1,  207,    2, 0x0a /* Public */,
      34,    1,  210,    2, 0x0a /* Public */,
      36,    0,  213,    2, 0x09 /* Protected */,
      37,    0,  214,    2, 0x09 /* Protected */,
      38,    0,  215,    2, 0x09 /* Protected */,
      39,    0,  216,    2, 0x09 /* Protected */,
      40,    0,  217,    2, 0x09 /* Protected */,
      41,    1,  218,    2, 0x09 /* Protected */,
      43,    1,  221,    2, 0x09 /* Protected */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Bool,    4,    5,    6,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9, QMetaType::Int,   10,   11,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, 0x80000000 | 24,   25,
    QMetaType::Void, 0x80000000 | 24,   25,
    QMetaType::Void, 0x80000000 | 24,   25,
    QMetaType::Void, 0x80000000 | 24,   25,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   32,
    QMetaType::Void, QMetaType::QString,   32,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   42,
    QMetaType::Void, QMetaType::QString,   42,

       0        // eod
};

void lay::MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->closed(); break;
        case 1: _t->current_pos((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 2: _t->clear_current_pos(); break;
        case 3: _t->message((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->clear_message(); break;
        case 5: _t->select_mode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->update_action_states(); break;
        case 7: _t->cancel(); break;
        case 8: _t->redraw(); break;
        case 9: _t->exit(); break;
        case 10: _t->close_current_view(); break;
        case 11: _t->close_view((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->tab_close_requested((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->open_recent((*reinterpret_cast< size_t(*)>(_a[1]))); break;
        case 14: _t->open_recent_session((*reinterpret_cast< size_t(*)>(_a[1]))); break;
        case 15: _t->open_recent_layer_properties((*reinterpret_cast< size_t(*)>(_a[1]))); break;
        case 16: _t->open_recent_bookmarks((*reinterpret_cast< size_t(*)>(_a[1]))); break;
        case 17: _t->view_selected((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->view_title_changed(); break;
        case 19: _t->show_help((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 20: _t->show_modal_help((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->dock_widget_visibility_changed((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->menu_changed(); break;
        case 23: _t->message_timer(); break;
        case 24: _t->edits_enabled_changed(); break;
        case 25: _t->menu_needs_update(); break;
        case 26: _t->file_changed_timer(); break;
        case 27: _t->file_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 28: _t->file_removed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::closed)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject lay::MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_lay__MainWindow.data,
    qt_meta_data_lay__MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__MainWindow.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "tl::Object"))
        return static_cast< tl::Object*>(this);
    if (!strcmp(_clname, "lay::DispatcherDelegate"))
        return static_cast< lay::DispatcherDelegate*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int lay::MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 29;
    }
    return _id;
}

// SIGNAL 0
void lay::MainWindow::closed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
