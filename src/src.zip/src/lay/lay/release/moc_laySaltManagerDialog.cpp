/****************************************************************************
** Meta object code from reading C++ file 'laySaltManagerDialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../laySaltManagerDialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'laySaltManagerDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_lay__SaltManagerDialog_t {
    QByteArrayData data[24];
    char stringdata0[388];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__SaltManagerDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__SaltManagerDialog_t qt_meta_stringdata_lay__SaltManagerDialog = {
    {
QT_MOC_LITERAL(0, 0, 22), // "lay::SaltManagerDialog"
QT_MOC_LITERAL(1, 23, 20), // "salt_about_to_change"
QT_MOC_LITERAL(2, 44, 0), // ""
QT_MOC_LITERAL(3, 45, 12), // "salt_changed"
QT_MOC_LITERAL(4, 58, 25), // "salt_mine_about_to_change"
QT_MOC_LITERAL(5, 84, 17), // "salt_mine_changed"
QT_MOC_LITERAL(6, 102, 16), // "selected_changed"
QT_MOC_LITERAL(7, 119, 28), // "mine_update_selected_changed"
QT_MOC_LITERAL(8, 148, 25), // "mine_new_selected_changed"
QT_MOC_LITERAL(9, 174, 15), // "edit_properties"
QT_MOC_LITERAL(10, 190, 12), // "mark_clicked"
QT_MOC_LITERAL(11, 203, 12), // "create_grain"
QT_MOC_LITERAL(12, 216, 12), // "delete_grain"
QT_MOC_LITERAL(13, 229, 12), // "mode_changed"
QT_MOC_LITERAL(14, 242, 5), // "apply"
QT_MOC_LITERAL(15, 248, 19), // "search_text_changed"
QT_MOC_LITERAL(16, 268, 4), // "text"
QT_MOC_LITERAL(17, 273, 20), // "show_marked_only_new"
QT_MOC_LITERAL(18, 294, 14), // "unmark_all_new"
QT_MOC_LITERAL(19, 309, 12), // "mark_all_new"
QT_MOC_LITERAL(20, 322, 23), // "show_marked_only_update"
QT_MOC_LITERAL(21, 346, 17), // "unmark_all_update"
QT_MOC_LITERAL(22, 364, 15), // "mark_all_update"
QT_MOC_LITERAL(23, 380, 7) // "refresh"

    },
    "lay::SaltManagerDialog\0salt_about_to_change\0"
    "\0salt_changed\0salt_mine_about_to_change\0"
    "salt_mine_changed\0selected_changed\0"
    "mine_update_selected_changed\0"
    "mine_new_selected_changed\0edit_properties\0"
    "mark_clicked\0create_grain\0delete_grain\0"
    "mode_changed\0apply\0search_text_changed\0"
    "text\0show_marked_only_new\0unmark_all_new\0"
    "mark_all_new\0show_marked_only_update\0"
    "unmark_all_update\0mark_all_update\0"
    "refresh"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__SaltManagerDialog[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  119,    2, 0x08 /* Private */,
       3,    0,  120,    2, 0x08 /* Private */,
       4,    0,  121,    2, 0x08 /* Private */,
       5,    0,  122,    2, 0x08 /* Private */,
       6,    0,  123,    2, 0x08 /* Private */,
       7,    0,  124,    2, 0x08 /* Private */,
       8,    0,  125,    2, 0x08 /* Private */,
       9,    0,  126,    2, 0x08 /* Private */,
      10,    0,  127,    2, 0x08 /* Private */,
      11,    0,  128,    2, 0x08 /* Private */,
      12,    0,  129,    2, 0x08 /* Private */,
      13,    0,  130,    2, 0x08 /* Private */,
      14,    0,  131,    2, 0x08 /* Private */,
      15,    1,  132,    2, 0x08 /* Private */,
      17,    0,  135,    2, 0x08 /* Private */,
      18,    0,  136,    2, 0x08 /* Private */,
      19,    0,  137,    2, 0x08 /* Private */,
      20,    0,  138,    2, 0x08 /* Private */,
      21,    0,  139,    2, 0x08 /* Private */,
      22,    0,  140,    2, 0x08 /* Private */,
      23,    0,  141,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void lay::SaltManagerDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SaltManagerDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->salt_about_to_change(); break;
        case 1: _t->salt_changed(); break;
        case 2: _t->salt_mine_about_to_change(); break;
        case 3: _t->salt_mine_changed(); break;
        case 4: _t->selected_changed(); break;
        case 5: _t->mine_update_selected_changed(); break;
        case 6: _t->mine_new_selected_changed(); break;
        case 7: _t->edit_properties(); break;
        case 8: _t->mark_clicked(); break;
        case 9: _t->create_grain(); break;
        case 10: _t->delete_grain(); break;
        case 11: _t->mode_changed(); break;
        case 12: _t->apply(); break;
        case 13: _t->search_text_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->show_marked_only_new(); break;
        case 15: _t->unmark_all_new(); break;
        case 16: _t->mark_all_new(); break;
        case 17: _t->show_marked_only_update(); break;
        case 18: _t->unmark_all_update(); break;
        case 19: _t->mark_all_update(); break;
        case 20: _t->refresh(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject lay::SaltManagerDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_lay__SaltManagerDialog.data,
    qt_meta_data_lay__SaltManagerDialog,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::SaltManagerDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::SaltManagerDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__SaltManagerDialog.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "tl::Object"))
        return static_cast< tl::Object*>(this);
    return QDialog::qt_metacast(_clname);
}

int lay::SaltManagerDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
