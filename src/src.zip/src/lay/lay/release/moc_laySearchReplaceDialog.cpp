/****************************************************************************
** Meta object code from reading C++ file 'laySearchReplaceDialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../laySearchReplaceDialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'laySearchReplaceDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_lay__SearchReplaceResults_t {
    QByteArrayData data[1];
    char stringdata0[26];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__SearchReplaceResults_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__SearchReplaceResults_t qt_meta_stringdata_lay__SearchReplaceResults = {
    {
QT_MOC_LITERAL(0, 0, 25) // "lay::SearchReplaceResults"

    },
    "lay::SearchReplaceResults"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__SearchReplaceResults[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void lay::SearchReplaceResults::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject lay::SearchReplaceResults::staticMetaObject = { {
    QMetaObject::SuperData::link<QAbstractItemModel::staticMetaObject>(),
    qt_meta_stringdata_lay__SearchReplaceResults.data,
    qt_meta_data_lay__SearchReplaceResults,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::SearchReplaceResults::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::SearchReplaceResults::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__SearchReplaceResults.stringdata0))
        return static_cast<void*>(this);
    return QAbstractItemModel::qt_metacast(_clname);
}

int lay::SearchReplaceResults::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractItemModel::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_lay__SearchReplaceDialog_t {
    QByteArrayData data[27];
    char stringdata0[531];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_lay__SearchReplaceDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_lay__SearchReplaceDialog_t qt_meta_stringdata_lay__SearchReplaceDialog = {
    {
QT_MOC_LITERAL(0, 0, 24), // "lay::SearchReplaceDialog"
QT_MOC_LITERAL(1, 25, 23), // "find_all_button_clicked"
QT_MOC_LITERAL(2, 49, 0), // ""
QT_MOC_LITERAL(3, 50, 21), // "delete_button_clicked"
QT_MOC_LITERAL(4, 72, 25), // "delete_all_button_clicked"
QT_MOC_LITERAL(5, 98, 22), // "replace_button_clicked"
QT_MOC_LITERAL(6, 121, 26), // "replace_all_button_clicked"
QT_MOC_LITERAL(7, 148, 24), // "configure_button_clicked"
QT_MOC_LITERAL(8, 173, 26), // "execute_all_button_clicked"
QT_MOC_LITERAL(9, 200, 31), // "execute_selected_button_clicked"
QT_MOC_LITERAL(10, 232, 24), // "add_saved_button_clicked"
QT_MOC_LITERAL(11, 257, 28), // "replace_saved_button_clicked"
QT_MOC_LITERAL(12, 286, 27), // "delete_saved_button_clicked"
QT_MOC_LITERAL(13, 314, 27), // "rename_saved_button_clicked"
QT_MOC_LITERAL(14, 342, 17), // "tab_index_changed"
QT_MOC_LITERAL(15, 360, 5), // "index"
QT_MOC_LITERAL(16, 366, 26), // "saved_query_double_clicked"
QT_MOC_LITERAL(17, 393, 26), // "recent_query_index_changed"
QT_MOC_LITERAL(18, 420, 24), // "result_selection_changed"
QT_MOC_LITERAL(19, 445, 22), // "header_columns_changed"
QT_MOC_LITERAL(20, 468, 4), // "from"
QT_MOC_LITERAL(21, 473, 2), // "to"
QT_MOC_LITERAL(22, 476, 6), // "cancel"
QT_MOC_LITERAL(23, 483, 11), // "cancel_exec"
QT_MOC_LITERAL(24, 495, 10), // "export_csv"
QT_MOC_LITERAL(25, 506, 10), // "export_rdb"
QT_MOC_LITERAL(26, 517, 13) // "export_layout"

    },
    "lay::SearchReplaceDialog\0"
    "find_all_button_clicked\0\0delete_button_clicked\0"
    "delete_all_button_clicked\0"
    "replace_button_clicked\0"
    "replace_all_button_clicked\0"
    "configure_button_clicked\0"
    "execute_all_button_clicked\0"
    "execute_selected_button_clicked\0"
    "add_saved_button_clicked\0"
    "replace_saved_button_clicked\0"
    "delete_saved_button_clicked\0"
    "rename_saved_button_clicked\0"
    "tab_index_changed\0index\0"
    "saved_query_double_clicked\0"
    "recent_query_index_changed\0"
    "result_selection_changed\0"
    "header_columns_changed\0from\0to\0cancel\0"
    "cancel_exec\0export_csv\0export_rdb\0"
    "export_layout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_lay__SearchReplaceDialog[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x08 /* Private */,
       3,    0,  125,    2, 0x08 /* Private */,
       4,    0,  126,    2, 0x08 /* Private */,
       5,    0,  127,    2, 0x08 /* Private */,
       6,    0,  128,    2, 0x08 /* Private */,
       7,    0,  129,    2, 0x08 /* Private */,
       8,    0,  130,    2, 0x08 /* Private */,
       9,    0,  131,    2, 0x08 /* Private */,
      10,    0,  132,    2, 0x08 /* Private */,
      11,    0,  133,    2, 0x08 /* Private */,
      12,    0,  134,    2, 0x08 /* Private */,
      13,    0,  135,    2, 0x08 /* Private */,
      14,    1,  136,    2, 0x08 /* Private */,
      16,    0,  139,    2, 0x08 /* Private */,
      17,    1,  140,    2, 0x08 /* Private */,
      18,    0,  143,    2, 0x08 /* Private */,
      19,    2,  144,    2, 0x08 /* Private */,
      22,    0,  149,    2, 0x08 /* Private */,
      23,    0,  150,    2, 0x08 /* Private */,
      24,    0,  151,    2, 0x08 /* Private */,
      25,    0,  152,    2, 0x08 /* Private */,
      26,    0,  153,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   20,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void lay::SearchReplaceDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SearchReplaceDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->find_all_button_clicked(); break;
        case 1: _t->delete_button_clicked(); break;
        case 2: _t->delete_all_button_clicked(); break;
        case 3: _t->replace_button_clicked(); break;
        case 4: _t->replace_all_button_clicked(); break;
        case 5: _t->configure_button_clicked(); break;
        case 6: _t->execute_all_button_clicked(); break;
        case 7: _t->execute_selected_button_clicked(); break;
        case 8: _t->add_saved_button_clicked(); break;
        case 9: _t->replace_saved_button_clicked(); break;
        case 10: _t->delete_saved_button_clicked(); break;
        case 11: _t->rename_saved_button_clicked(); break;
        case 12: _t->tab_index_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->saved_query_double_clicked(); break;
        case 14: _t->recent_query_index_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->result_selection_changed(); break;
        case 16: _t->header_columns_changed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 17: _t->cancel(); break;
        case 18: _t->cancel_exec(); break;
        case 19: _t->export_csv(); break;
        case 20: _t->export_rdb(); break;
        case 21: _t->export_layout(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject lay::SearchReplaceDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<lay::Browser::staticMetaObject>(),
    qt_meta_stringdata_lay__SearchReplaceDialog.data,
    qt_meta_data_lay__SearchReplaceDialog,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *lay::SearchReplaceDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *lay::SearchReplaceDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_lay__SearchReplaceDialog.stringdata0))
        return static_cast<void*>(this);
    return lay::Browser::qt_metacast(_clname);
}

int lay::SearchReplaceDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = lay::Browser::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
